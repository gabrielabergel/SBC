'use client'

import { useEffect, useState } from 'react'

export default function Loader({ onFinish }) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    const minDuration = 2000 // minimum visible time (ms)
    const start = performance.now()

    const handleReady = () => {
      const now = performance.now()
      const elapsed = now - start
      const remaining = Math.max(0, minDuration - elapsed)
      setTimeout(() => {
        setIsVisible(false)
        onFinish?.()
      }, remaining)
    }

    // Optionally wait for a video element or a callback
    handleReady()
  }, [onFinish])

  return (
    <div
      className={`
        fixed inset-0 z-[9999] flex items-center justify-center
        bg-white transition-opacity duration-700 ease-in-out
        ${isVisible ? 'opacity-100' : 'opacity-0 pointer-events-none'}
      `}
    >
      <h1 className="text-black text-[8px] md:text-[14px] font-sectraBlack tracking-wide">
        Samy Bouard Cart
      </h1>
    </div>
  )
}
