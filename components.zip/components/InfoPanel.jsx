export default function InfoPanel({ onClose }) {
  const handleClick = (e) => {
    if (!e.target.closest('.interactive-zone')) {
      onClose()
    }
  }

  // Définir l'animation directement en style JSX
  const dashAnimation = `
    @keyframes dashDrop {
      0% { transform: scaleY(0); opacity: 0; }
      100% { transform: scaleY(1); opacity: 1; }
    }
  `;

  return (
    <div
      className="absolute inset-0 z-20 pointer-events-none transition-opacity duration-500"
      onClick={handleClick}
    >
      {/* Style pour les animations des tirets */}
      <style jsx>{dashAnimation}</style>

      {/* Grille pour les tirets - positionnée en absolu avec la même structure que la grille de contenu */}
      <div className="absolute top-0 left-0 right-0 px-8 z-30">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-30">
          {/* Tiret colonne 1 */}
          <div className="relative">
            <div style={{ 
              position: 'absolute', 
              top: '0', 
              left: '-4px',
              height: '14px', 
              width: '1px', 
              backgroundColor: 'black',
              transformOrigin: 'top',
              transform: 'scaleY(0)', 
              opacity: '0', 
              animation: 'dashDrop 0.3s forwards',
              animationDelay: '0.2s'
            }} />
          </div>
          
          {/* Tiret colonne 2 */}
          <div className="relative">
            <div style={{ 
              position: 'absolute', 
              top: '0', 
              left: '-4px',
              height: '14px', 
              width: '1px', 
              backgroundColor: 'black',
              transformOrigin: 'top',
              transform: 'scaleY(0)', 
              opacity: '0', 
              animation: 'dashDrop 0.3s forwards',
              animationDelay: '0.4s'
            }} />
          </div>
          
          {/* Tiret colonne 3 */}
          <div className="relative">
            <div style={{ 
              position: 'absolute', 
              top: '0', 
              left: '-4px',
              height: '14px', 
              width: '1px', 
              backgroundColor: 'black',
              transformOrigin: 'top',
              transform: 'scaleY(0)', 
              opacity: '0', 
              animation: 'dashDrop 0.3s forwards',
              animationDelay: '0.6s'
            }} />
          </div>
          
          {/* Tiret colonne 4 */}
          <div className="relative">
            <div style={{ 
              position: 'absolute', 
              top: '0', 
              left: '-4px',
              height: '14px', 
              width: '1px', 
              backgroundColor: 'black',
              transformOrigin: 'top',
              transform: 'scaleY(0)', 
              opacity: '0', 
              animation: 'dashDrop 0.3s forwards',
              animationDelay: '0.8s'
            }} />
          </div>
        </div>
      </div>

      {/* Contenu principal */}
      <div className="flex flex-col text-black px-8 pb-10 pt-4 text-xs overflow-y-auto h-full w-full pointer-events-auto">
        <div className="flex-grow grid grid-cols-1 md:grid-cols-4 gap-30 items-start">

          {/* Colonne 1 : Samy - SANS tiret */}
          <div className="fade-start animate-fadein delay-1 whitespace-pre-line leading-relaxed relative">
            <p className="font-sectraBlack mb-6"></p>
            is a French director obsessed by image and its evocative power.  
            He works mainly on fashion campaigns, music documentaries  
            and feature films.

            <br /><br />
            {/* Contact info avec interlignage réduit */}
            <div className="space-y-0.2 mb-13">
              <p><span className="font-sectraBlack">Mail:</span> info@samybouardcart.com</p>
              <p><span className="font-sectraBlack">Instagram:</span> samybouardcart</p>
              <p><span className="font-sectraBlack">Phone:</span> +33 6 01 25 14 03</p>
            </div>
          </div>

          {/* Colonne 2 : Awards - SANS tiret */}
          <div className="fade-start animate-fadein delay-2 leading-tight relative">
            <p className="font-sectraBlack mb-2">AWARDS AND DISTINCTIONS</p>

            {/* Premier bloc award */}
            <div className="space-y-0.5 mb-3">
              <p><span className="font-sectraBlack">Year:</span> 2022</p>
              <p><span className="font-sectraBlack">Price Name:</span> Europe Film Festival</p>
              <p><span className="font-sectraBlack">Film:</span> Symbiosis</p>
              <p><span className="font-sectraBlack">Location:</span> Europe</p>
            </div>

            {/* Deuxième bloc award */}
            <div className="space-y-0.5 mb-3">
              <p><span className="font-sectraBlack">Year:</span> 2021</p>
              <p><span className="font-sectraBlack">Price Name:</span> FCAC</p>
              <p><span className="font-sectraBlack">Film:</span> Symbiosis</p>
              <p><span className="font-sectraBlack">Location:</span> Geneva</p>
            </div>

            {/* Troisième bloc award */}
            <div className="space-y-0.5 mb-3">
              <p><span className="font-sectraBlack">Year:</span> 2020</p>
              <p><span className="font-sectraBlack">Price Name:</span> The Design Film Festival</p>
              <p><span className="font-sectraBlack">Film:</span> The Last Resort</p>
              <p><span className="font-sectraBlack">Location:</span> London</p>
            </div>

            {/* Quatrième bloc award */}
            <div className="space-y-0.5 mb-3">
              <p><span className="font-sectraBlack">Year:</span> 2019</p>
              <p><span className="font-sectraBlack">Price Name:</span> Cineglobe International Film Festival</p>
              <p><span className="font-sectraBlack">Film:</span> Rocca</p>
              <p><span className="font-sectraBlack">Location:</span> Geneva</p>
            </div>

            {/* Cinquième bloc award */}
            <div className="space-y-0.5">
              <p><span className="font-sectraBlack">Year:</span> 2018</p>
              <p><span className="font-sectraBlack">Price Name:</span> Prix de la Fondation BEA</p>
              <p><span className="font-sectraBlack">Film:</span> Fractal Exploration</p>
              <p><span className="font-sectraBlack">Location:</span> Geneva</p>
            </div>
          </div>

          {/* Colonne 3 - SANS tiret */}
          <div className="fade-start animate-fadein delay-3 leading-relaxed relative">
            <p className="font-sectraBlack">PORTFOLIO ↘</p>
          </div>

          {/* Colonne 4 - SANS tiret */}
          <div className="fade-start animate-fadein delay-4 leading-relaxed relative">
            <p className="font-sectraBlack">LEGAL NOTICE</p>
          </div>

        </div>
      </div>
    </div>
  )
}