'use client'

import { useRef, useEffect, useState, useMemo } from 'react'

function formatTime(seconds) {
  const m = String(Math.floor(seconds / 60)).padStart(2, '0')
  const s = String(Math.floor(seconds % 60)).padStart(2, '0')
  const ms = String(Math.floor((seconds % 1) * 100)).padStart(2, '0')
  return `${m}'${s}''${ms}`
}

const VIGNETTE_WIDTH = 50

export default function TimelineScroll({
  currentTime,
  duration,
  onSeek,
  isPlaying,
  muteControl,
  videoRef,
  onScrollUpdate,
}) {
  const wrapperRef = useRef(null)
  const friseRef = useRef(null)
  const animationFrame = useRef(null)
  const timelineRef = useRef(null)

  const [isDragging, setIsDragging] = useState(false)
  const [startX, setStartX] = useState(0)
  const [startScrollX, setStartScrollX] = useState(0)
  const [internalTime, setInternalTime] = useState(0)

  const wasPlayingBeforeDrag = useRef(false)
  const continuousPosition = useRef(0)
  const sectionWidthRef = useRef(1)

  const lastSyncedTime = useRef(0)
  const lastUpdate = useRef(performance.now())

  const NUM_THUMBS = 51

  const baseThumbs = useMemo(
    () =>
      Array.from({ length: NUM_THUMBS }, (_, i) => ({
        src: `/thumbs/thumb_${String(i).padStart(3, '0')}.jpg`,
        time: ((i + 1) * duration) / (NUM_THUMBS + 1),
      })),
    [duration]
  )

  const thumbs = [...baseThumbs, ...baseThumbs, ...baseThumbs]
  const sectionWidth = NUM_THUMBS * VIGNETTE_WIDTH
  const totalWidth = sectionWidth * 3
  sectionWidthRef.current = sectionWidth

  const updateScrollX = (scrollX) => {
    const containerWidth = wrapperRef.current?.offsetWidth || window.innerWidth
    const centeredScrollX = scrollX + containerWidth / 2 - VIGNETTE_WIDTH / 2
    onScrollUpdate?.(centeredScrollX)
  }

  const handleMouseDown = (e) => {
    setIsDragging(true)
    cancelAnimationFrame(animationFrame.current)
    setStartX(e.clientX)
    setStartScrollX(continuousPosition.current)

    if (videoRef?.current) {
      wasPlayingBeforeDrag.current = !videoRef.current.paused
      videoRef.current.pause()
    }
  }

  const handleMouseMove = (e) => {
    if (!isDragging || !duration) return
    const dx = e.clientX - startX
    const newScrollX = startScrollX - dx
    const relativePosition = ((newScrollX % sectionWidth) + sectionWidth) % sectionWidth
    const newTime = (relativePosition / sectionWidth) * duration
    if (!isFinite(newTime)) return

    onSeek(newTime)
    setInternalTime(newTime)
    continuousPosition.current = newScrollX

    updateScrollX(newScrollX)

    if (friseRef.current) {
      friseRef.current.style.transform = `translateX(-${newScrollX}px)`
    }

    if (timelineRef.current) {
      if (dx < -10) {
        timelineRef.current.setAttribute('data-cursor', 'left')
      } else if (dx > 10) {
        timelineRef.current.setAttribute('data-cursor', 'right')
      } else {
        timelineRef.current.setAttribute('data-cursor', 'timeline')
      }
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
    lastSyncedTime.current = internalTime
    lastUpdate.current = performance.now()
    animationFrame.current = requestAnimationFrame(animate)

    if (videoRef?.current && wasPlayingBeforeDrag.current) {
      videoRef.current.play()
    }

    if (timelineRef.current) {
      timelineRef.current.setAttribute('data-cursor', 'timeline')
    }
  }

  const handleTouchStart = (e) => {
    if (e.touches.length === 1) {
      setIsDragging(true)
      cancelAnimationFrame(animationFrame.current)
      const touch = e.touches[0]
      setStartX(touch.clientX)
      setStartScrollX(continuousPosition.current)

      if (videoRef?.current) {
        wasPlayingBeforeDrag.current = !videoRef.current.paused
        videoRef.current.pause()
      }
    }
  }

  const handleTouchMove = (e) => {
    if (!isDragging || !duration) return
    const touch = e.touches[0]
    const dx = touch.clientX - startX
    const newScrollX = startScrollX - dx
    const relativePosition = ((newScrollX % sectionWidth) + sectionWidth) % sectionWidth
    const newTime = (relativePosition / sectionWidth) * duration
    if (!isFinite(newTime)) return

    onSeek(newTime)
    setInternalTime(newTime)
    continuousPosition.current = newScrollX

    updateScrollX(newScrollX)

    if (friseRef.current) {
      friseRef.current.style.transform = `translateX(-${newScrollX}px)`
    }
  }

  const handleTouchEnd = () => {
    setIsDragging(false)
    lastSyncedTime.current = internalTime
    lastUpdate.current = performance.now()
    animationFrame.current = requestAnimationFrame(animate)

    if (videoRef?.current && wasPlayingBeforeDrag.current) {
      videoRef.current.play()
    }
  }

  useEffect(() => {
    if (!isDragging) {
      lastSyncedTime.current = currentTime
      lastUpdate.current = performance.now()
    }
  }, [currentTime, isDragging])

  function animate(now) {
    const elapsed = (now - lastUpdate.current) / 1000
    const rawTime = lastSyncedTime.current + elapsed
    const clampedTime = Math.min(rawTime, duration - 0.0001) // ✅ empêche de dépasser la dernière vignette

    setInternalTime(clampedTime)

    const section = sectionWidthRef.current
    const timePosition = (clampedTime / duration) * section
    const scrollX = section + timePosition
    continuousPosition.current = scrollX

    updateScrollX(scrollX)

    if (friseRef.current) {
      friseRef.current.style.transform = `translateX(-${scrollX}px)`
    }

    animationFrame.current = requestAnimationFrame(animate)
  }

  useEffect(() => {
    if (isPlaying && !isDragging) {
      animationFrame.current = requestAnimationFrame(animate)
    }
    return () => cancelAnimationFrame(animationFrame.current)
  }, [isPlaying, isDragging, duration])

  useEffect(() => {
    const interval = setInterval(() => {
      if (!isDragging) {
        setInternalTime(currentTime)
        lastSyncedTime.current = currentTime
        lastUpdate.current = performance.now()
      }
    }, 500)
    return () => clearInterval(interval)
  }, [currentTime, isDragging])

  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove)
      window.addEventListener('mouseup', handleMouseUp)
      window.addEventListener('touchmove', handleTouchMove, { passive: false })
      window.addEventListener('touchend', handleTouchEnd)
    } else {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
      window.removeEventListener('touchmove', handleTouchMove)
      window.removeEventListener('touchend', handleTouchEnd)
    }
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
      window.removeEventListener('touchmove', handleTouchMove)
      window.removeEventListener('touchend', handleTouchEnd)
    }
  }, [isDragging])

  const section = sectionWidthRef.current
  const markerOffset = -30
  const relativeScroll =
    ((continuousPosition.current - markerOffset) % section + section) % section
  const visibleTime = (relativeScroll / section) * duration

  return (
    <div className="absolute top-1/2 left-0 right-0 z-30 transform -translate-y-1/2 h-24 pointer-events-auto interactive-zone">
      <div className="absolute top-[-20px] left-0 right-0 flex justify-between pl-4 pr-6 z-30 pt-2">
        <div className="text-xs font-sectraBlack text-black pointer-events-none select-none">
          {formatTime(visibleTime)}
        </div>
        <div className="pointer-events-auto font-sectraBlack interactive-zone">
          {muteControl}
        </div>
      </div>

      <div
        ref={(el) => {
          wrapperRef.current = el
          timelineRef.current = el
        }}
        className="relative w-full h-full pointer-events-auto overflow-hidden interactive-zone"
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        data-cursor="timeline"
      >
        <div
          ref={friseRef}
          className="absolute top-0 left-0 h-full flex items-center will-change-transform"
          style={{ width: `${totalWidth}px` }}
        >
          {thumbs.map((thumb, index) => (
            <img
              key={index}
              src={thumb.src}
              alt={`thumb-${index}`}
              className="h-[60px] w-[50px] object-cover select-none"
              draggable="false"
            />
          ))}
        </div>

        <div className="absolute -left-5 top-1/2 -translate-y-[57%] z-50 pointer-events-none">
          <img
            src="/icons/marker.svg"
            alt="curseur timeline"
            className="h-17 w-25"
            draggable="false"
          />
        </div>
      </div>
    </div>
  )
}
