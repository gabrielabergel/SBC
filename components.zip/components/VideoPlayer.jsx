'use client'

import { useEffect, useState } from 'react'
import Loader from './Loader'

export default function VideoPlayer({ onTimeUpdate, videoRef, showInfo, toggleInfo }) {
  const [isDesktop, setIsDesktop] = useState(true)
  const [isReady, setIsReady] = useState(false)

  // Détection dynamique de l’écran
  useEffect(() => {
    const checkScreen = () => {
      setIsDesktop(window.innerWidth >= 1024)
    }
    checkScreen()
    window.addEventListener('resize', checkScreen)
    return () => window.removeEventListener('resize', checkScreen)
  }, [])

  // Gestion du temps vidéo
  useEffect(() => {
    const video = videoRef.current
    const handleTimeUpdate = () => {
      if (!video) return
      const current = video.currentTime
      const duration = video.duration
      onTimeUpdate(current, duration)
    }

    video?.addEventListener('timeupdate', handleTimeUpdate)
    return () => {
      video?.removeEventListener('timeupdate', handleTimeUpdate)
    }
  }, [onTimeUpdate, videoRef])

  // Chargement de la vidéo
  const handleLoadedData = () => {
    setIsReady(true)
  }

  // Gestion du clic sur fond (desktop uniquement)
  const handleBackgroundClick = (e) => {
    if (isDesktop && !e.target.closest('.interactive-zone')) {
      toggleInfo()
    }
  }

  const videoSrc = isDesktop
    ? '/video/SBC_Showreel_Home.mp4'
    : '/video/SBC_Showreel_Mobile.mp4'

  return (
    <>
      {!isReady && <Loader />}
      <div className="fixed inset-0 z-0 overflow-hidden">
        {/* Clic desktop uniquement */}
        <div className="absolute inset-0 z-10" onClick={handleBackgroundClick} />

        {/* Voile blanc si info */}
        {showInfo && (
          <div className="absolute inset-0 z-10 bg-white/40 pointer-events-none transition-opacity duration-100" />
        )}

        {/* Conteneur vidéo */}
        <div
          className={`w-full h-full flex justify-center items-center transition duration-100 will-change-transform ${
            showInfo ? 'blur-xl scale-[1.001]' : ''
          }`}
        >
          <video
            ref={videoRef}
            className={`${
              isDesktop
                ? 'max-w-[80%] max-h-[80%]'
                : 'w-full h-full object-cover'
            } pointer-events-none`}
            autoPlay
            loop
            muted
            playsInline
            onLoadedData={handleLoadedData}
            key={videoSrc}
          >
            <source src={videoSrc} type="video/mp4" />
          </video>
        </div>
      </div>
    </>
  )
}
