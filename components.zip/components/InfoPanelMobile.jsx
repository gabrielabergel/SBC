'use client'

import { useEffect } from 'react'

export default function InfoPanelMobile({ onClose }) {
  useEffect(() => {
    document.body.classList.add('hide-title')
    return () => document.body.classList.remove('hide-title')
  }, [])

  const dashAnimation = `
    @keyframes dashDrop {
      0% { transform: scaleY(0); opacity: 0; }
      100% { transform: scaleY(1); opacity: 1; }
    }
  `

  const scrollNext = () => {
    const container = document.querySelector('[data-infoscroll]')
    if (container) {
      container.scrollBy({ left: window.innerWidth, behavior: 'smooth' })
    }
  }

  return (
    <div className="absolute inset-0 z-20 pointer-events-none transition-opacity duration-500">
      <style jsx>{dashAnimation}</style>

      {/* Tirets en haut (desktop only) */}
      <div className="hidden md:block absolute top-0 left-0 right-0 px-8 z-30">
        <div className="grid grid-cols-4 gap-30">
          {[0.2, 0.4, 0.6, 0.8].map((delay, i) => (
            <div key={i} className="relative">
              <div
                style={{
                  position: 'absolute',
                  top: '0',
                  left: '-4px',
                  height: '14px',
                  width: '1px',
                  backgroundColor: 'black',
                  transformOrigin: 'top',
                  transform: 'scaleY(0)',
                  opacity: '0',
                  animation: `dashDrop 0.3s forwards`,
                  animationDelay: `${delay}s`,
                }}
              />
            </div>
          ))}
        </div>
      </div>

      {/* Bouton scroll next mobile placé juste au-dessus du milieu à droite */}
      <div className="absolute top-1/2 right-4 transform -translate-y-[120%] z-40 md:hidden pointer-events-auto">
        <button onClick={scrollNext} className="text-black bg-transparent">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
               strokeWidth="1.5" stroke="currentColor" className="w-6 h-6">
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>

      {/* Slides mobile */}
      <div className="w-full h-full pointer-events-auto">
        <div
          className="flex md:grid md:grid-cols-4 overflow-x-auto snap-x snap-mandatory h-full text-[11px] md:text-xs md:px-8 pt-6 pb-12 text-black"
          data-infoscroll
        >
          {/* Slide 1 */}
          <div className="snap-start min-w-[100vw] px-6 pr-12 leading-[1.2] whitespace-pre-line fade-start animate-fadein delay-1">
            <p className="font-sectraBlack mb-1 text-[12px]">SAMY BOUARD CART</p>
            is a French director obsessed by image and its evocative power.  
            He works mainly on fashion campaigns, music documentaries  
            and feature films.

            <br /><br />
            <div className="space-y-0.5 mb-12">
              <p><span className="font-sectraBlack">Mail:</span> info@samybouardcart.com</p>
              <p><span className="font-sectraBlack">Instagram:</span> samybouardcart</p>
              <p><span className="font-sectraBlack">Phone:</span> +33 6 01 25 14 03</p>
            </div>
          </div>

          {/* Slide 2 */}
          <div className="snap-start min-w-[100vw] px-6 pr-12 leading-[1.2] fade-start animate-fadein delay-2">
            <p className="font-sectraBlack mb-2 text-[12px]">AWARDS AND DISTINCTIONS</p>
            {[{ year: '2022', price: 'Europe Film Festival', film: 'Symbiosis', location: 'Europe' },
              { year: '2021', price: 'FCAC', film: 'Symbiosis', location: 'Geneva' },
              { year: '2020', price: 'The Design Film Festival', film: 'The Last Resort', location: 'London' },
              { year: '2019', price: 'Cineglobe International Film Festival', film: 'Rocca', location: 'Geneva' },
            ].map((item, i) => (
              <div key={i} className="space-y-0.5 mb-1">
                <p><span className="font-sectraBlack">Year:</span> {item.year}</p>
                <p><span className="font-sectraBlack">Price Name:</span> {item.price}</p>
                <p><span className="font-sectraBlack">Film:</span> {item.film}</p>
                <p><span className="font-sectraBlack">Location:</span> {item.location}</p>
              </div>
            ))}
          </div>

          {/* Slide 3 */}
          <div className="snap-start min-w-[100vw] px-6 pr-12 leading-snug fade-start animate-fadein delay-3">
            <p className="font-sectraBlack text-[12px]">PORTFOLIO ↘</p>
          </div>

          {/* Slide 4 */}
          <div className="snap-start min-w-[100vw] px-6 pr-12 leading-snug fade-start animate-fadein delay-4">
            <p className="font-sectraBlack text-[12px]">LEGAL NOTICE</p>
          </div>
        </div>
      </div>
    </div>
  )
}
